import { useEffect, useState } from "react";
import axios from "axios";
import { FaRegCheckCircle } from "react-icons/fa";
import { useNavigate, useSearchParams } from "react-router-dom";

const PaymentSuccess = () => {
  const [loading, setLoading] = useState(true);
  const [paymentData, setPaymentData] = useState(null);
  const navigate = useNavigate();

  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get("session_id");
  const orderId = searchParams.get("order_id");
console.log("seesion",paymentData);
  useEffect(() => {
    if (sessionId && orderId) {
      verifyPayment();
    } else {
      setLoading(false);
    }
  }, []);

  const verifyPayment = async () => {
    try {
      const formData = new FormData();
      formData.append("session_id", sessionId);
      formData.append("order_id", orderId);

      const res = await axios.post(
        "http://tech-shop.techsaga.live/api/payment-success",
        formData,
        {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      if (res.data.status === "success") {
        setPaymentData(res.data);
      }
    } catch (err) {
      console.error("Payment success error", err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <h2 style={{ textAlign: "center" }}>Verifying payment...</h2>;
  }

  return (
    <div className="payment-wrapper success">
      <FaRegCheckCircle size={80} color="#28a745" />
      <h2>Payment Successful 🎉</h2>

      <div className="payment-info">
        <p><strong>Order ID:</strong> {paymentData?.order_id}</p>
        <p><strong>Amount:</strong> ₹{paymentData?.amount}</p>
        <p><strong>Currency:</strong> {paymentData?.currency}</p>
        <p><strong>Paid On:</strong> {paymentData?.paid_on}</p>
        <p><strong>Email:</strong> {paymentData?.customer_email}</p>
      </div>

      <button onClick={() => navigate("/")}>Continue Shopping</button>
    </div>
  );
};

export default PaymentSuccess;

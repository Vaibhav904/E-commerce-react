import React, { useContext, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Drift from "drift-zoom";
import Addcart from "./Addcart";
import { AuthContext } from "../Context/AuthContext";
import { getProductById } from "../utils/requests";
import axios from "axios";
import { addToCart, setCartFromApi } from "../Redux/CartSlice";
import { useDispatch } from "react-redux";

export default function Alldetail() {
  const { id } = useParams();
    const dispatch = useDispatch();
 const { token } = useContext(AuthContext);
  const [product, setProduct] = useState(null);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [isOpen, setIsOpen] = useState(false);
   const [showModal, setShowModal] = useState(false);
   
   const [productDetails, setProductDetails] = useState(null);

  /* ================= FETCH PRODUCT ================= */
  const fetchProduct = async () => {
    try {
      const res = await getProductById(id);
      setProduct(res.product); // 🔴 API key product
    } catch (err) {
      console.error("Product fetch error:", err);
    }
  };

  useEffect(() => {
    fetchProduct();
  }, [id]);

  /* ================= IMAGE SLIDER ================= */
  const images = product?.images?.length
    ? product.images
    : [product?.thumbnail];

  const handlePrevImage = () => {
    setCurrentImageIndex((prev) =>
      prev === 0 ? images.length - 1 : prev - 1
    );
  };

  const handleNextImage = () => {
    setCurrentImageIndex((prev) =>
      prev === images.length - 1 ? 0 : prev + 1
    );
  };

  /* ================= AUTO SLIDE ================= */
  useEffect(() => {
    if (!images?.length) return;
    const interval = setInterval(handleNextImage, 5000);
    return () => clearInterval(interval);
  }, [images]);

  /* ================= DRIFT ZOOM ================= */
  useEffect(() => {
    const triggerEl = document.querySelector(".drift-demo-trigger");
    const paneEl = document.querySelector(".zoom-pane");

    if (triggerEl && paneEl) {
      new Drift(triggerEl, {
        paneContainer: paneEl,
        inlinePane: 769,
        containInline: true,
        hoverBoundingBox: true,
      });
    }
  }, [currentImageIndex]);

  if (!product) return <div className="text-center py-5">Loading...</div>;





    const fetchCart = async () => {
    try {
      const res = await axios.post(
        "http://tech-shop.techsaga.live/api/cart/view",
        {},
        {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      dispatch(setCartFromApi(res.data.cart));
      console.log("Cart fetched", res.data.cart);
    } catch (error) {
      console.log("Fetch cart error", error);
    }
  };
  const handleAddToCart = async () => {
  setIsOpen(true);
  window.scrollTo({ top: 0, behavior: "smooth" });

  try {
    if (token) {
      const res = await axios.post(
        "http://tech-shop.techsaga.live/api/cart/add",
        {
          product_id: product.id,
          quantity: quantity,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
          },
        }
      );

      console.log("API add success", res.data);
      await fetchCart();
    } else {
      dispatch(
        addToCart({
          product_id: product.id,
          title: product.title,
          price: product.price,
          image: product.images?.[0],
          quantity: quantity,
        })
      );
      console.log("Redux add success");
    }
  } catch (error) {
    console.log("Add to cart failed", error.response?.data || error);
  }
};



  return (
    <div className="container my-4">
      <div className="row gx-5">
        {/* ================= LEFT : IMAGES ================= */}
        <div className="col-md-6 position-relative">
          <div className="main-image-container">
            <button className="nav-arrow nav-arrow-left" onClick={handlePrevImage}>
              &#10094;
            </button>

            <img
              className="drift-demo-trigger"
              src={images[currentImageIndex]}
              data-zoom={images[currentImageIndex]}
              alt={product.title}
            />

            <button className="nav-arrow nav-arrow-right" onClick={handleNextImage}>
              &#10095;
            </button>
          </div>

          <div className="zoom-pane"></div>

          <div className="thumbnail-list">
            {images.map((img, i) => (
              <img
                key={i}
                src={img}
                className={i === currentImageIndex ? "active" : ""}
                onClick={() => setCurrentImageIndex(i)}
                alt=""
              />
            ))}
          </div>
        </div>

        {/* ================= RIGHT : DETAILS ================= */}
        <div className="col-md-6">
          <h2>{product.title}</h2>
          <p className="text-muted">{product.category}</p>

          <div className="price">
            ₹{product.Salesprice}
            <span className="original-price ms-2">
              ₹{product.price}
            </span>
            <span className="discount-badge ms-2">
              {product.discountPercentage}% OFF
            </span>
          </div>

          <p className="mt-3">{product.description}</p>

          <div className="mb-2">
            <strong>Stock:</strong>{" "}
            {product.stock > 0 ? "In Stock" : "Out of Stock"}
          </div>

          {/* ================= QUANTITY ================= */}
          <div className="quantity-controls my-3">
            <button onClick={() => quantity > 1 && setQuantity(quantity - 1)}>
              −
            </button>
            <input
              type="number"
              value={quantity}
              min="1"
              max={product.stock}
              onChange={(e) => setQuantity(+e.target.value)}
            />
            <button
              onClick={() =>
                quantity < product.stock && setQuantity(quantity + 1)
              }
            >
              +
            </button>
          </div>

          {/* ================= ADD TO CART ================= */}
          <button
            className="btn-add-to-cart"
            
             onClick={handleAddToCart}
          >
            <i className="fas fa-shopping-cart me-2"></i>
            Add to Cart
          </button>

          <div className="delivery-info mt-4">
            <i className="fas fa-truck"></i>
            <span className="ms-2">
              Estimated delivery in 4–6 business days
            </span>
          </div>
        </div>
      </div>

      <Addcart open={isOpen} close={() => setIsOpen(false)} />
    </div>
  );
}

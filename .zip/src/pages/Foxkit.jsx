import React from 'react'

export default function Foxkit() {
  return (
    <div className="headerbt">Foxkit</div>
  )
}

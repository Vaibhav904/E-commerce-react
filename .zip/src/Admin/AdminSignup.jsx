import React from 'react';

export default function AdminSignup() {
  return (
    <div>
      <h3>VAibhav awasthi</h3>
    </div>
  );
}
